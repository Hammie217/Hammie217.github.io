To playback your archive simply uncompress (extract) this zip file to disk and double click on the 'index.htm' file in the 'archive' directory.

To post this to your website for others to play simply copy the archive folder (which should contain the index.html file and a folder named 'lib') to the desired location on your web server and distrubute the appropriate link, ie http://www.yourdomain.com/training/archive if you saved the archive folder under the 'training' directory.

