/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "TSS1.h"
#include "RED_LED.h"
#include "TU1.h"
#include "GREEN_LED.h"
#include "BLUE_LED.h"
#include "TU2.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
/* User includes (#include below this line is not maintained by Processor Expert) */

static void delay(int ms){// general purpose delay
	int i,ii;
	for(ii=0;ii<ms;ii++){//run for length of delay
		for(i=0;i<1000;i++){}//run empty for loop 1000 times (about 1 ms)
	}
}

static void TurnLedOn(int i){//turns on a specific LED based on the input
	switch(i){
	case 0://0 for red
		RED_LED_SetRatio16(RED_LED_DeviceData,0xFFFF);
		BLUE_LED_SetRatio16(RED_LED_DeviceData,0);
		GREEN_LED_SetRatio16(RED_LED_DeviceData,0);
		break;
	case 1://1 for green
		RED_LED_SetRatio16(RED_LED_DeviceData,0);
		BLUE_LED_SetRatio16(RED_LED_DeviceData,0);
		GREEN_LED_SetRatio16(RED_LED_DeviceData,0xFFFF);
		break;
	case 2://2 for blue
		RED_LED_SetRatio16(RED_LED_DeviceData,0);
		BLUE_LED_SetRatio16(RED_LED_DeviceData,0xFFFF);
		GREEN_LED_SetRatio16(RED_LED_DeviceData,0);
		break;
	case 3://3 for all off
		RED_LED_SetRatio16(RED_LED_DeviceData,0);
		BLUE_LED_SetRatio16(RED_LED_DeviceData,0);
		GREEN_LED_SetRatio16(RED_LED_DeviceData,0);

	}
}

static int GetInput(){//function to get and return input
	int ii=3;
	while(1){//keep going untill broken
		TSS_Task();

		  if (TSS1_cKey0.DynamicStatus.Movement){
			  if(TSS1_cKey0.Position>45){//if above 45(the end of the sensor)
				  TurnLedOn(2);//light blue led
				  ii=2;//set last led touched to blue
			   }
			   else if(TSS1_cKey0.Position<15){//else if below 15 (left)
				   TurnLedOn(0);//light red
			       ii=0;//set last touched to red
			   }
			   else{//else must be inbetween touched
				   ii=1;//last led touched set to green
			       TurnLedOn(1);//light green
			   }
		  }
		  else if(ii<3){//if selected and let go
			  TurnLedOn(3);
			  delay(1000);
			  break;//exit loop
		  }
}
	return ii;//return last touched value
}

static void flash(){//creates the rgb initiation and ending cycle
	int Leds[3]={1,43690,21845};//create an array for the 3 values each with an offset
	int Up[3] ={1,1,-1},i;//set direction (increment/decrement) for the 3 leds
	while(Leds[0]!=0){//stop after 1 cycle
		for(i=0;i<3;i++){//for each of the 3 leds
			if((Leds[i]==65535)||(Leds[i]==0)){//if at the max value then swap direction
				Up[i]*=-1;}
			Leds[i]+=Up[i];}
		BLUE_LED_SetRatio16(BLUE_LED_DeviceData,Leds[0]);//set all the LED values
		RED_LED_SetRatio16(RED_LED_DeviceData,Leds[1]);
		GREEN_LED_SetRatio16(GREEN_LED_DeviceData,Leds[2]);
		}
}

/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/

	PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */
  int i,ii,score,pattern[50],failed;//define local variables
  TurnLedOn(3);
  for(;;){
	  TSS_Task();//pend touch
	  if(TSS1_cKey0.Events.Touch)//if touched
	  {
		  srand(TSS1_cKey0.Position);//seed based on touch position (1 in 64 randoms)
		  while(TSS1_cKey0.Events.Touch)//Debounce
		  	  	  		TSS_Task();
		  TurnLedOn(3);//turn all off
		  score=1;//set starting values
		  failed=0;
		  flash();
		  	for(i=0;i<50;i++){
	  		pattern[i]=rand()%3;
	  	}
	  	while(!failed){
	  for(i=0;i<score;i++){//print values untill score length
		  delay(1000);
		  TurnLedOn(pattern[i]);
		  delay(1000);
		  TurnLedOn(3);

	  }

	  for(i=0;i<score;i++){//get inputs for score length
		  ii=GetInput();
		  TurnLedOn(3);
		  delay(1000);
		  if(ii!=pattern[i]){//check if equal else break out
			  failed=1;
			  break;
		  }
	  	  }
	  score++;//if not broken out then increment score
	  	}
	  	flash();//if broken out then state fail and restart code
	  	delay(10);
	  	TurnLedOn(3);
	  }

}
  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/
